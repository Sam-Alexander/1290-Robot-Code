package org.usfirst.frc.team1290.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Joystick.RumbleType;

public class Dualshock {
    Joystick controller;
    static final int LEFT_VERT_AXIS  = 1;
    static final int LEFT_HORZ_AXIS  = 0;
    static final int RIGHT_VERT_AXIS = 3;
    static final int RIGHT_HORZ_AXIS = 2;
    
    Dualshock(int portNumber)
    {
        controller = new Joystick(portNumber);
    }
    
    double getLeftHorizontal()
    {
        return controller.getRawAxis(LEFT_HORZ_AXIS);
    }
    
    double getLeftVertical()
    {
        return -controller.getRawAxis(LEFT_VERT_AXIS);
    }
    
    double getRightHorizontal()
    {
        return controller.getRawAxis(RIGHT_HORZ_AXIS);
    }
    
    double getRightVertical()
    {
        return -controller.getRawAxis(RIGHT_VERT_AXIS);
    }
    
    boolean getButton(int buttonNum)
    {
    	return controller.getRawButton(buttonNum);
    }
    
    int getPOV()
    {
    	return controller.getPOV();
    }
    
    void rumble() {
//    	controller.setRumble(RumbleType.kLeftRumble, .5f);
//    	controller.setRumble(RumbleType.kRightRumble, .5f);
    }
}