package org.usfirst.frc.team1290.robot;

import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.RobotDrive;

public class RobotDriveFixed extends RobotDrive{

	public RobotDriveFixed(CANJaguar frontLeftJag, CANJaguar backLeftJag, CANJaguar frontRightJag, CANJaguar backRightJag) {
		super(frontLeftJag, backLeftJag, frontRightJag, backRightJag);
	}
	
	
}
