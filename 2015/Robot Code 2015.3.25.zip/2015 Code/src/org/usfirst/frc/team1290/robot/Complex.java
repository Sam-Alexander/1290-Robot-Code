package org.usfirst.frc.team1290.robot;

import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Complex extends Command {
	CANJaguar[] jag;
	RobotDriveFixed drive;
	public Complex(CANJaguar[] cj, RobotDriveFixed dr) {
		
		jag = cj;
	
		drive = dr;
		
	}
/* AUTONOMOUS PLAN 
 * grab tote
 * lift it
 * turn 90 degrees
 * move forward (maybe)
 * lower arm
 * drop tote
 * @see edu.wpi.first.wpilibj.command.Command#initialize()
 */
	
	@Override
	protected void initialize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void execute() {
		
		drive.tankDrive(-0.55, -0.55);
	}

	@Override
	protected boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void end() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void interrupted() {
		// TODO Auto-generated method stub
		
	}
	
	
}
