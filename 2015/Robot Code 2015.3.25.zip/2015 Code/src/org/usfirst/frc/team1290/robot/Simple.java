package org.usfirst.frc.team1290.robot;

import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Simple extends Command {
	CANJaguar[] jag;
	RobotDriveFixed drive;
	public Simple(CANJaguar[] cj, RobotDriveFixed dr) {
		
		jag = cj;
	
		drive = dr;
		
	}
	
	@Override
	protected void initialize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void execute() {
		drive.tankDrive(.55, .55);
	}

	@Override
	protected boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void end() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void interrupted() {
		// TODO Auto-generated method stub
		
	}
	
	
}
