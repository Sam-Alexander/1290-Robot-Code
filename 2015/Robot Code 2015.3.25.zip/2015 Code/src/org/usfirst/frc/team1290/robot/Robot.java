
package org.usfirst.frc.team1290.robot;

import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.tables.ITable;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends IterativeRobot {
	
	final double  DRIVE_CUTOFF = 1;
	final boolean GRAB_ON = true; //OPEN ARM
	final boolean GRAB_OFF = false; //CLOSE ARM
	final boolean BRAKE_ON = true;
	final boolean BRAKE_OFF = false;
	final int     SIMPLE_AUTO = 0;
	final int     COMPLEX_AUTO = 1;
	final int	  CLOWN_AUTO = 2;
	final int 	  LIMIT_SWITCH_CEILING = 0;
	final int 	  LIMIT_SWITCH_FLOOR = 1;
	
	
	Command autoCommand;
	CANJaguar[] jag = new CANJaguar[8]; //lines up with jaguar numbering (2-7)
	Solenoid grab, brake; 
	RobotDriveFixed drive;
	Dualshock joystick;
	double driveL, driveR, previousDriveValueL, previousDriveValueR;
	DigitalInput limitSwitchCeiling, limitSwitchFloor;
	SendableChooser autoChoice;
	ITable itable;
	int stop = 0;
	Timer t = new Timer();

    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */
    public void robotInit() {
    	//initialize jaguars to their positions
    	for(int i = 2; i < jag.length; i++) {
    		jag[i] = new CANJaguar(i);
    		SmartDashboard.putBoolean("Jag " + i, jag[i].isAlive());
    	}
    	drive = new RobotDriveFixed(jag[2], jag[3], jag[4], jag[5]);
    	
    	autoChoice = new SendableChooser();
    	autoChoice.addObject("Simple", new Simple(jag, drive));
    	autoChoice.addObject("Complex", new Complex(jag, drive));
    	//autoChoice.addObject("Clowny", CLOWN_AUTO);
    	SmartDashboard.putData("Autonomous Choice", autoChoice);
    	//brake = new Solenoid(0); //brake
    	grab = new Solenoid(1);  //grabbing piston on pulley
    	joystick = new Dualshock(0);
    	limitSwitchCeiling = new DigitalInput(LIMIT_SWITCH_CEILING);
    	limitSwitchFloor = new DigitalInput(LIMIT_SWITCH_FLOOR);
    	previousDriveValueL = 0;
    	previousDriveValueR = 0;
    	
    }
    
    public void autonomousInit() {

   		autoCommand = (Command) autoChoice.getSelected();
  		autoCommand.start();
  		t.reset();
  		t.start();
	
    }

    /**
     * This function is called periodically during autonomous
     */
    public void autonomousPeriodic() {
    	
//    	if(autoChoice.getSelected().equals("Simple")) {
    		//drive forward

    	SmartDashboard.putBoolean("Is Running", autoCommand.isRunning());
//    	Simple = "Simple", Complex = "Complex"
    	SmartDashboard.putString("Current Command", autoChoice.getSelected().toString());
    	if(autoChoice.getSelected().toString().equals("Complex")){
	    	if(t.get()< 2){
	    		grab.set(GRAB_OFF);
	    	}else if(t.get() >= 2 && t.get() < 3) {
	    		drive.tankDrive(.5, .5);
	    	}else if(t.get() >= 3 && t.get() < 5) {
	    		grab.set(GRAB_ON);
	    	}else if(t.get() < 9) {
	    		Scheduler.getInstance().run();
	    		
	    	}else{
	    		autoCommand.cancel();
	
	    	}
    	}else if(autoChoice.getSelected().toString().equals("Simple")){
    		if(t.get() < 3)
	    		Scheduler.getInstance().run();
	    		
    	}
    	
//    	} else if(autoChoice.getSelected().equals(COMPLEX_AUTO)) {
//    		//get things and then drive
//    	} else if(autoChoice.getSelected().equals(CLOWN_AUTO)) {
//    		//spin
//    	}
    	
    }
    
    public void autonomous() {
        System.out.println("Default autonomous() method running, consider providing your own");
    }

    /**
     * This function is called periodically during operator control
     */
    public void teleopPeriodic() {
    	
    	if(joystick.getButton(8)) {
    		driveL = joystick.getLeftVertical();
    		driveR = joystick.getRightVertical();
    	} else {
    		driveL = joystick.getLeftVertical() / 1.41; //y=x^2 -> y=(x^2)/2
    		driveR = joystick.getRightVertical()/ 1.41;
    	}
    	if(joystick.getButton(11) && joystick.getButton(12)) {
	    	final double MAX_DIFFERENCE = 0.05;
	    	if(Math.abs(previousDriveValueL - driveL) <= MAX_DIFFERENCE) //check if last drive value is significantly different from joystick
	    		driveL = driveL; //if yes, drive at the average of the values
	    	else {
	    		if(driveL < previousDriveValueL) {
	    			driveL = previousDriveValueL - MAX_DIFFERENCE;
	    		}else{
	    			driveL = previousDriveValueL + MAX_DIFFERENCE; //experiment with multiplying 
	    		}												  //max difference by 2
	    	}
	    	if(Math.abs(previousDriveValueR - driveR) <= MAX_DIFFERENCE)
	    		driveR = driveR;
	    	else{
	    		if(driveR < previousDriveValueR) {
	    			driveR = previousDriveValueR - MAX_DIFFERENCE;
	    		}else{
	    			driveR = previousDriveValueR + MAX_DIFFERENCE; //right here too
	    		}
	    	}
    	}
    	if(joystick.getButton(6)) //RIP mode 7
    		drive.tankDrive(driveR, driveR, true);
    	else
    		drive.tankDrive(driveL, driveR, true);
    	
    	//Get values for joystick
    	
//        SmartDashboard.putNumber("Joystick L", joystick.getLeftVertical());
//        SmartDashboard.putNumber("Joystick R", joystick.getRightVertical());
//        SmartDashboard.putNumber("drive L", driveL);
//        SmartDashboard.putNumber("drive R", driveR);
//        SmartDashboard.putBoolean("Limit Switch Floor", limitSwitchFloor.get());
//        SmartDashboard.putBoolean("Limit Switch Ceiling", limitSwitchCeiling.get());
    	
    	//Wheels voltage
//        for(int i = 2; i < 8; i++) {
//        	SmartDashboard.putNumber("Jag " + i + " voltage", jag[i].getOutputVoltage());
//        }
        previousDriveValueL = driveL;
        previousDriveValueR = driveR;
        
        final double ARM_LIFT_SPEED = 0.2;
        double armDirection = .1;
//        if(!limitSwitchCeiling.get()) {
//        	stop++;
//        }
//        if(stop > 0 && !limitSwitchCeiling.get())
//        	stop = 0;
//        else if (stop > 0) stop++;
        if(joystick.getButton(5)) {// && limitSwitchCeiling.get() && stop == 0) {
        	armDirection = ARM_LIFT_SPEED*3;
        }
        if(joystick.getButton(7)) { //&& !limitSwitchFloor.get()) {
        	//stop = 0;
        	armDirection = -ARM_LIFT_SPEED;
        } 
        
        //Voltage
        
//        SmartDashboard.putNumber("Bus Voltage Jag6", jag[6].getBusVoltage());
//        SmartDashboard.putNumber("Speed Jag6", jag[6].getSpeed());
//        SmartDashboard.putNumber("Bus Voltage Jag7", jag[7].getBusVoltage());
//        SmartDashboard.putNumber("Speed Jag7", jag[7].getSpeed());
        
        jag[6].set(armDirection);
        jag[7].set(armDirection);
        //if(armDirection != 0) {
        	//brake.set(BRAKE_ON); //this probably won't work as-is
        //} else {
        	//brake.set(BRAKE_OFF); //because pistons take more time than motors
        //}
        
//        if(joystick.getButton(1))  //this
//        	brake.set(BRAKE_ON);   //is
//        else if(joystick.getButton(4)) //testing
//        	brake.set(BRAKE_OFF);  //code
        if(joystick.getButton(2)) {
        	grab.set(GRAB_ON); //when 2 is pressed, undo the grabbing piston (let it go~)
        } else if(joystick.getButton(3)) {
        	grab.set(GRAB_OFF); //when 3 is pressed, activate the grabbing piston 
        }
        
        //button 5 = forward on CAN 6/7 | button 7 = backwards on CAN 6/7
//        jag[2].set(joystick.getLeftVertical());
//        jag[3].set(joystick.getLeftVertical());
    }
    
    /**
     * This function is called periodically during test mode
     */
    public void testPeriodic() {
//    	joystick.rumble();
    }
    
}
